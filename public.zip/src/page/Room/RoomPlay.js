import React from 'react'
import MusicPlay from "./Main/MusicPlayer/MusicPlay";

function roomPlay() {
  return (
    <MusicPlay/>
  )
}

export default roomPlay