import React from 'react'

function RoomAnno() {
  return (
    <div>RoomAnno</div>
  )
}

export default RoomAnno