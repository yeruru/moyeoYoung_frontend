import React from 'react'

function NoteDetail() {
  return (
    <div>NoteDetail</div>
  )
}

export default NoteDetail