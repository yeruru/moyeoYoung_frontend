import React from 'react'

function UserPage() {
  return (
    <div className='wrap'>UserPage</div>
  )
}

export default UserPage