import React from 'react';

const MyPage = () => {
    return (
        <div className='wrap'>
            마이페이지입니다.
        </div>
    );
};

export default MyPage;